import os
import shutil
import uuid
from flask import *
from database import *
import smtplib
from email.mime.text import MIMEText
from flask_mail import Mail


deliverystaff=Blueprint('staff',__name__)



@deliverystaff.route('/login1',methods=['post'])
def login1():
    username = request.form['username']
    password = request.form['password']

    q="select * from login where username='%s' and password='%s'"%(username,password)
    res=select(q)
    print(res)
    if res:
        
        if res[0]['usertype']=='deliverystaff':
            login_id=res[0]['login_id'] 
            print(login_id)
            q="select * from deliverystaff where login_id='%s'"%(login_id)
            result=select(q)
            if result:
                staff_id=result[0]['staff_id']
                return jsonify(status="ok",lid=login_id,uid=staff_id)
            else:
                return jsonify(status="no")
        else:
            return jsonify(status="no")
    else:
            return jsonify(status="no")  
        
@deliverystaff.route('/deliverystaff_view_profile',methods=['post'])
def deliverystaff_view_profile():
    a=[]
    data={}
    uid=request.form['uid']
    q = "select * from deliverystaff where staff_id='%s'"%(uid)
    g=select(q)
    for i in g:
        a.append({"id":i['staff_id'],"name":i['name'],"phone":i['phone'],"email":i['email'],"place":i['place'],"pin":i['pin'],"photo":i['photo']})
    return jsonify(data=a,status='ok')

@deliverystaff.route('/deliverystaff_view_assigned_work',methods=['post'])
def deliverystaff_view_assigned_work():
    a=[]
    data={}
    uid=request.form['uid']
    q = "SELECT * FROM `assign` INNER JOIN `request` USING(request_id) INNER JOIN users USING(user_id) WHERE staff_id='%s' and request.status='asigned'"%(uid)
    g=select(q)
    for i in g:
        a.append({"id":i['request_id'],"name":i['name'],"place":i['place'],"phone":i['phone'],"pin":i['pin'],"requestfor":i['requestfor'],"status":i['status']})
    return jsonify(data=a,status='ok')

@deliverystaff.route('/deliverystaff_update_status',methods=['post'])
def deliverystaff_update_status():
    a=[]
    data={}
    # uid=request.form['uid']
    sid=request.form['sid']
    q = "update request set status='delivered' where request_id='%s'"%(sid)
    insert(q)
    
    p = "update assign set status='delivered' where request_id='%s'"%(sid)
    insert(p)

    return jsonify(status="ok") 


@deliverystaff.route('/deliverystaff_view_all_bookings',methods=['post'])
def deliverystaff_view_all_bookings():
    a=[]
    data={}
    uid=request.form['uid']
    q = " SELECT * FROM `assign` INNER JOIN `request` USING(request_id) WHERE staff_id='%s' AND `assign`.`status`='delivered'"%(uid)
    g=select(q)
    for i in g:
        a.append({"id":i['assign_id'],"requestfor":i['requestfor'],"date":i['date'],"status":i['status']})
    return jsonify(data=a,status='ok')
        
@deliverystaff.route('/deliverystaff_view_rating',methods=['post'])
def deliverystaff_view_rating():
    a=[]
    data={}
    uid=request.form['uid']
    q = "select * from rating inner join users using(user_id) where staff_id='%s'"%(uid)
    g=select(q)
    for i in g:
        a.append({"id":i['rating_id'],"name":i['name'],"rating":i['rating']})
    return jsonify(data=a,status='ok')
