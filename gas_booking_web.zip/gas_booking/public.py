import uuid
from flask import *
from database import *
import smtplib
from email.mime.text import MIMEText
from flask_mail import Mail
import random

public=Blueprint('public',__name__)

@public.route('/')
def publichome():
    return render_template('public/publichome.html')

@public.route('/login',methods=['get','post'])
def login():
    if 'submit' in request.form:
        usernamee=request.form['username']
        passwordd=request.form['Password']
        fu="select * from login where username ='%s' and password='%s'"%(usernamee,passwordd)
        res=select(fu)
        if res:
            session['login_id']=res[0]['login_id']
            if res[0]['usertype']=='admin':
                return redirect(url_for('admin.adminhome'))
            elif res[0]['usertype']=='user':
                pt="select   * from users where login_id='%s'"%(session['login_id'])
                kis=select(pt)
                if kis:
                    session['user_id']=kis[0]['user_id']
                return redirect(url_for('user.userhome'))
            return '''<script>alert('invalid username or password');window.location='/login';</script>'''            
    return render_template('public/login.html')   


@public.route('/user_registration',methods=['get','post'])
def user_registration():
    if 'submit' in request.form:
        name=request.form['name']
        address=request.form['address']
        email=request.form['email']
        phone=request.form['phone']
        place=request.form['place']
        pin=request.form['pin']
        image=request.files['image']
        path="static/"+str(uuid.uuid4())+image.filename
        image.save(path)
        username=request.form['username']
        password=request.form['password']

        j="insert into login values(null,'%s','%s','user')"%(username,password)
        l=insert(j)
        p="insert into users values(null,'%s','%s','%s','%s','%s','%s','%s','%s')"%(l,name,phone,email,address,place,pin,path)
        insert(p)   
        return redirect(url_for("public.login"))
    return render_template('public/user_registration.html')