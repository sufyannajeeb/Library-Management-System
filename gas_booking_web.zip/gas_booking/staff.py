from flask import *
from database import *
import smtplib
from email.mime.text import MIMEText
from flask_mail import Mail
import random

user=Blueprint('user',__name__)

@user.route('/')
def user_home():
    return render_template('user/user_home.html')