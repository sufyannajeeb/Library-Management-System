import uuid
from django.http import JsonResponse
from flask import *
from database import *
from datetime import datetime 

admin=Blueprint ('admin',__name__)

@admin.route('/adminhome')
def adminhome():
    return render_template('admin/adminhome.html')  

@admin.route('/admin_manage_delivery_staff',methods=['get','post'])
def admin_manage_delivery_staff():
    data={}
    if 'submit' in request.form:
        name=request.form['name']
        address=request.form['address']
        email=request.form['email']
        phone=request.form['phone']
        place=request.form['place']
        pin=request.form['pin']
        image=request.files['image']
        path="static/"+str(uuid.uuid4())+image.filename
        image.save(path)
        username=request.form['username']
        password=request.form['password']

        j="insert into login values(null,'%s','%s','deliverystaff')"%(username,password)
        l=insert(j)
        p="insert into deliverystaff values(null,'%s','%s','%s','%s','%s','%s','%s','%s')"%(l,name,phone,email,address,place,pin,path)
        insert(p)   
        return redirect(url_for('admin.admin_manage_delivery_staff'))

    x="select * from deliverystaff"
    data['police']=select(x)

    if 'action' in request.args:
        action=request.args['action']
        loginid=request.args['logid']
    else:
        action=None
    
    
    if action=='update':
        u="select * from deliverystaff where login_id='%s'"%(loginid)
        data['updatess']=select(u)

    if 'update' in request.form:
        name=request.form['name']
        address=request.form['address']
        email=request.form['email']
        phone=request.form['phone']
        place=request.form['place']
        pin=request.form['pin']
        image=request.files['image']
        path="static/"+str(uuid.uuid4())+image.filename
        image.save(path)
        y="update deliverystaff set name='%s',phone='%s',email='%s',address='%s',place='%s',pin='%s',photo='%s' where login_id='%s'"%(name,phone,email,address,place,pin,path,loginid)
        update(y )
        return redirect(url_for('admin.admin_manage_delivery_staff'))
    
    if action=='delete':
        p="delete from deliverystaff where login_id='%s'"%(loginid)
        delete(p)
        o="delete from login where login_id='%s'"%(loginid)
        return redirect(url_for('admin.admin_manage_delivery_staff'))

    return render_template('admin/admin_manage_delivery_staff.html',data=data)


@admin.route('/admin_view_complaints',methods=['get','post'])
def admin_view_complaints():
    data={}

    ko="SELECT * FROM complaint INNER JOIN users USING(user_id)"
    data['complaint']=select(ko)

    return render_template('admin/admin_view_complaints.html',data=data)

@admin.route('/admin_send_complaint_reply',methods=['get','post'])
def admin_send_complaint_reply():
    data={}

    if 'complaint' in request.args:
        complaintid=request.args['complaint']
    else:
        action=None

    if 'submit' in request.form:
        reply=request.form['reply']
        po="update complaint set reply='%s' where complaint_id='%s'"%(reply,complaintid)
        update(po)
        return redirect(url_for('admin.admin_view_complaints'))

    return render_template('admin/admin_send_complaint_reply.html',data=data)


@admin.route('/admin_view_gas_connection_requet', methods=['GET', 'POST'])
def admin_view_gas_connection_request():
    data = {}
    x = "SELECT * FROM request inner join users using(user_id) WHERE requestfor='gasconnection'"
    data['police'] = select(x)

    if 'action' in request.args:
        action = request.args['action']
        req_id = request.args['request']
    else:
        action = None

    if action == 'accept':
        oo = "UPDATE request SET status='verified' WHERE request_id='%s'" % (req_id)
        update(oo)
        return redirect(url_for('admin.admin_view_gas_connection_request'))

    return render_template('admin/admin_view_gas_connection_requet.html', data=data)

@admin.route('/admin_assign_staff_for_gas_connection_request', methods=['GET', 'POST'])
def admin_assign_staff_for_gas_connection_request():
    data = {}

    ggg="select * from deliverystaff"
    data['deliverystaff']=select(ggg)

    requestid=request.args['requestid']

    if 'submit' in request.form:
        staffname=request.form['staffname']
        date = datetime.now()
        po="insert into assign values(null,'%s','%s','pending','%s')"%(requestid,staffname,date)
        insert(po)
        yu="update request set status='asigned' where request_id='%s'"%(requestid)
        update(yu)
        return redirect(url_for('admin.admin_view_gas_connection_request'))

    return render_template('admin/admin_assign_staff_for_gas_connection_request.html', data=data)

@admin.route('/admin_view_refill_request', methods=['GET', 'POST'])
def admin_view_refill_request():
    data = {}
    x = "SELECT * FROM request inner join users using(user_id) WHERE requestfor='refill'"
    data['police'] = select(x)

    if 'action' in request.args:
        action = request.args['action']
        req_id = request.args['request']
    else:
        action = None

    if action == 'accept':
        oo = "UPDATE request SET status='accepted' WHERE request_id='%s'" % (req_id)
        update(oo)
        return redirect(url_for('admin.admin_view_refill_request'))

    return render_template('admin/admin_view_refill_request.html', data=data)

@admin.route('/admin_assign_staff_for_refill_request', methods=['GET', 'POST'])
def admin_assign_staff_for_refill_request():
    data = {}

    ggg="select * from deliverystaff"
    data['deliverystaff']=select(ggg)

    requestid=request.args['requestid']

    if 'submit' in request.form:
        staffname=request.form['staffname']
        date = datetime.now()
        po="insert into assign values(null,'%s','%s','pending','%s')"%(requestid,staffname,date)
        insert(po)
        yu="update request set status='asigned' where request_id='%s'"%(requestid)
        update(yu)
        return redirect(url_for('admin.admin_view_refill_request'))

    return render_template('admin/admin_assign_staff_for_refill_request.html', data=data)

@admin.route('/admin_view_staff_rating',methods=['get','post'])
def admin_view_staff_rating():
    data={}

    ko="SELECT *,`deliverystaff`.name AS staffname FROM `rating` INNER JOIN `deliverystaff` USING(staff_id) INNER JOIN users USING(user_id)"
    data['rating']=select(ko)

    return render_template('admin/admin_view_staff_rating.html',data=data)


@admin.route('/admin_update_stock',methods=['get','post'])
def admin_update_stock():
    data={}
    if 'submit' in request.form:
        stock=request.form['stock']
        date=request.form['date']
        p="insert into stock values(null,'%s','pending','%s')"%(stock,date)
        insert(p)   
        return redirect(url_for('admin.adminhome'))
    return render_template('admin/admin_update_stock.html',data=data)



@admin.route('/admin_view_gas_connection_request_payment',methods=['get','post'])
def admin_view_gas_connection_request_payment():
    data={}
    reqid=request.args['requestid']

    ko="SELECT * FROM `payment` INNER JOIN`request` USING(`request_id`) WHERE request_id='%s'"%(reqid)
    data['payment']=select(ko)

    return render_template('admin/admin_view_gas_connection_request_payment.html',data=data)

@admin.route('/admin_view_refill_request_payment',methods=['get','post'])
def admin_view_refill_request_payment():
    data={}
    reqid=request.args['requestid']

    ko="SELECT * FROM `payment` INNER JOIN`request` USING(`request_id`) WHERE request_id='%s'"%(reqid)
    data['refill']=select(ko)

    return render_template('admin/admin_view_refill_request_payment.html',data=data)



