import uuid
from flask import *
from database import *
import smtplib
from email.mime.text import MIMEText
from flask_mail import Mail
import random
from datetime import datetime 

user=Blueprint('user',__name__)

@user.route('/userhome')
def userhome():
    return render_template('user/userhome.html')


@user.route('/user_send_complaint',methods=['get','post'])
def user_send_complaint():
    data={}

    hh="select * from complaint where user_id='%s'"%(session['user_id'])
    data['complaint']=select(hh)

    if 'submit' in request.form:
        complaint=request.form['complaint']
        date = datetime.now()
        iou="insert into complaint values(null,'%s','%s','pending','%s')"%(session['user_id'],complaint,date)
        insert(iou)
        return redirect(url_for('user.user_send_complaint'))
    return render_template('user/user_send_complaint.html',data=data)


@user.route('/user_view_profile',methods=['get','post'])
def user_view_profile():
    data={}
    x="select * from users where user_id='%s'"%(session['user_id'])
    data['user']=select(x)

    if 'action' in request.args:
        action=request.args['action']
        loginid=request.args['logid']
    else:
        action=None
    
    
    if action=='update':
        u="select * from users where login_id='%s'"%(loginid)
        data['updatess']=select(u)

    if 'update' in request.form:
        name=request.form['name']
        address=request.form['address']
        email=request.form['email']
        phone=request.form['phone']
        place=request.form['place']
        pin=request.form['pin']
        image=request.files['image']
        path="static/"+str(uuid.uuid4())+image.filename
        image.save(path)
        y="update users set name='%s',phone='%s',email='%s',address='%s',place='%s',pin='%s',photo='%s' where login_id='%s'"%(name,phone,email,address,place,pin,path,loginid)
        update(y )
        return redirect(url_for('user.user_view_profile'))

    return render_template('user/user_view_profile.html',data=data)


@user.route('/user_send_request_for_gasconnection',methods=['get','post'])
def user_send_request_for_gasconnection():
    data={}

    if 'submit' in request.form:
        description=request.form['description']
        date = datetime.now()
        iou="insert into request values(null,'%s','%s','gasconnection','pending','%s')"%(session['user_id'],description,date)
        insert(iou)
        return redirect(url_for('user.user_send_request_for_gasconnection'))
    return render_template('user/user_send_request_for_gasconnection.html',data=data)


@user.route('/user_view_gasconnection_request_status',methods=['get','post'])
def user_view_gasconnection_request_status():
    data={}
    ki="SELECT * FROM request WHERE requestfor='gasconnection' and user_id='%s'"%(session['user_id'])
    data['gasconnection']=select(ki)
    return render_template('user/user_view_gasconnection_request_status.html',data=data)


@user.route('/user_make_payment_for_gasconnection',methods=['get','post'])
def user_make_payment_for_gasconnection():
    data={}

    requestid=request.args['requestid']

    if 'submit' in request.form:
        iou="insert into payment values(null,'%s','%s','750','paid')"%(session['user_id'],requestid)
        insert(iou)
        lk="update request set status='paid' where request_id='%s'"%(requestid)
        insert(lk)
        return redirect(url_for('user.userhome'))
    return render_template('user/user_make_payment_for_gasconnection.html',data=data)

@user.route('/user_send_refill_request',methods=['get','post'])
def user_send_refill_request():
    data={}

    if 'submit' in request.form:
        description=request.form['description']
        date = datetime.now()
        iou="insert into request values(null,'%s','%s','refill','pending','%s')"%(session['user_id'],description,date)
        insert(iou)
        return redirect(url_for('user.user_view_refill_request_status'))
    return render_template('user/user_send_refill_request.html',data=data)

@user.route('/user_view_refill_request_status',methods=['get','post'])
def user_view_refill_request_status():
    data={}
    ki="SELECT * FROM request WHERE requestfor='refill' and user_id='%s'"%(session['user_id'])
    data['refill']=select(ki)
    return render_template('user/user_view_refill_request_status.html',data=data)


@user.route('/user_make_payment_for_refill',methods=['get','post'])
def user_make_payment_for_refill():
    data={}

    requestid=request.args['requestid']

    if 'submit' in request.form:
        iou="insert into payment values(null,'%s','%s','550','paid')"%(session['user_id'],requestid)
        insert(iou)
        lk="update request set status='paid' where request_id='%s'"%(requestid)
        insert(lk)
        return redirect(url_for('user.userhome'))
    return render_template('user/user_make_payment_for_refill.html',data=data)




@user.route('/user_view_all_bookings',methods=['get','post'])
def user_view_all_bookings():
    data={}
    ki="SELECT * FROM request WHERE user_id='%s'"%(session['user_id'])
    data['allbookings']=select(ki)
    return render_template('user/user_view_all_bookings.html',data=data)

@user.route('/add_deliveryboy_rating',methods=['get','post'])
def add_deliveryboy_rating():
    data={}
    ki="SELECT * FROM deliverystaff"
    data['police']=select(ki)

    if 'action' in request.args:
        action=request.args['action']
        staffid=request.args['logid']
    else:
        action=None
    
    
    if action=='update':
        u="select * from deliverystaff where staff_id='%s'"%(staffid)
        data['updatess']=select(u)

    if 'update' in request.form:
        rating=request.form['rating']
        
        y="insert into rating values(null,'%s','%s','%s','pending')"%(staffid,session['user_id'],rating)
        update(y )
        return redirect(url_for('user.userhome'))

    return render_template('user/add_deliveryboy_rating.html',data=data)

